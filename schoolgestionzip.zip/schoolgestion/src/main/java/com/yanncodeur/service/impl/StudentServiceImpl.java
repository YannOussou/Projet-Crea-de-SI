package com.yanncodeur.service.impl;

import java.util.List;

import com.yanncodeur.entities.Student;
import com.yanncodeur.repos.StudentRepository;
import com.yanncodeur.service.StudentService;

public class StudentServiceImpl implements StudentService{

	
	private StudentRepository studentRepository;
	
	public StudentServiceImpl(StudentRepository studentRepository) {
		super();
		this.studentRepository = studentRepository;
	}


	
	@Override
	public List<Student> VoirToutLesEleves() {
		// TODO Auto-generated method stub
		return studentRepository.findAll();
	}

}

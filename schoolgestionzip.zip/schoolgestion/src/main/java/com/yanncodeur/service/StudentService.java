package com.yanncodeur.service;

import java.util.List;

import com.yanncodeur.entities.Student;

public interface StudentService {
	
	List<Student>VoirToutLesEleves();  // service de listing
}

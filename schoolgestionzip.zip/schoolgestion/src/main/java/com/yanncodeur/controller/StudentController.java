package com.yanncodeur.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


import com.yanncodeur.entities.Student;
import com.yanncodeur.service.StudentService;

@Controller
public class StudentController {

	private StudentService studentService;

	public StudentController(StudentService studentService) {
		super();
		this.studentService = studentService;
	}
	
	@GetMapping("/student")
	public String VoirToutLesEleves(Model model) {
		model.addAttribute("student", studentService.VoirToutLesEleves());
		return "students";
		
	}
	
	
	
}

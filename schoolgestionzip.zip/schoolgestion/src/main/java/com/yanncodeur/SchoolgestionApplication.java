package com.yanncodeur;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolgestionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchoolgestionApplication.class, args);
	}

}

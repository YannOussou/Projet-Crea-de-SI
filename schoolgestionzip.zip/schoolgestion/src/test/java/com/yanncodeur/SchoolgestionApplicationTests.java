package com.yanncodeur;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolgestionApplicationTests {

	@Test
	void contextLoads() {
	}

}
